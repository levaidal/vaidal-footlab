# FootLab · v0.2

Sandbox de simulación futbolística. Esta versión añade el laboratorio de acciones al editor v0.1 y cambia el nombre del proyecto. No incluye partidos completos todavía.

## Abrir y publicar

- Extrae todos los archivos manteniendo las carpetas. Abre `index.html` en Chrome o usa Live Server desde VS Code.
- Exporta primero tu base de datos desde la versión anterior. Copia los archivos de esta versión en la raíz de tu repositorio (reemplaza `index.html`, conserva `css/` y `js/`). No subas el ZIP como sustituto del código.
- En GitHub Pages utiliza la rama `main` y `/(root)` si ya estaba configurado así. No necesitas cambiar el nombre del repositorio ni la dirección de la web. Si cambias de origen web o de archivo local, importa tu JSON de nuevo. El almacenamiento local no se sincroniza entre usuarios o navegadores.
- No se incluye la base de LaLiga en esta distribución. Puedes importar el JSON v1 que ya tienes. No se necesitan dependencias ni servidor de datos.

## Archivos

- `index.html`: estructura y navegación.
- `css/styles.css`: diseño.
- `js/model.js`: atributos, medias y validación de bases de datos.
- `js/app.js`: editor, clubes, comparador, importación y persistencia.
- `js/engine.js`: motor puro, independiente de la interfaz.
- `js/lab.js`: interfaz para configurar experimentos.
- `tests/engine.test.js`: pruebas automáticas opcionales (Node.js: `node tests/engine.test.js`).
- `FootLab_formato.md`: especificación JSON v1.
- `MOTOR.md`: reglas experimentales.

## Uso

Selecciona una acción, dos participantes, energía, presión y dificultad. Las probabilidades cambian instantáneamente. Ejecuta una acción o un lote de hasta 100.000; con la misma semilla y configuración obtendrás los mismos resultados. Despliega el cálculo para consultar atributos, pesos y modificadores. Los experimentos no alteran las fichas guardadas.

Los coeficientes son hipótesis iniciales, no probabilidades calibradas con datos de partidos reales. Los atributos de la base de LaLiga también incluyen estimaciones. El siguiente paso será encadenar acciones en posesiones y simular partidos.
