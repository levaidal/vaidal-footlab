# FootLab · v0.3.2 — Sequence Studio

Sandbox de simulación futbolística. Conserva el editor y laboratorio de acciones v0.2 y conserva el laboratorio de jugadas v0.3.1 y añade intervalos de posesiones encadenadas. No simula un partido completo todavía.

## Actualizar

1. Exporta tu base de datos desde la versión anterior (copia de seguridad).
2. Extrae el ZIP y copia su contenido en la raíz del proyecto, sustituyendo los archivos anteriores y conservando las carpetas `css/`, `js/` y `tests/`.
3. Abre `index.html` en Chrome o con Live Server desde VS Code. No requiere dependencias ni servidor de datos.
4. Sube los archivos nuevos y modificados a tu repositorio GitHub y haz commit. No subas el ZIP como sustituto del código. Si GitHub Pages ya publica `main` / `root`, conserva su configuración.
5. Abre la misma URL y navegador para conservar el almacenamiento local. Si falta tu plantilla, importa tu JSON v1. El ZIP no incluye datos de terceros (LaLiga).

## Uso

- El Laboratorio de secuencias es la página inicial. Selecciona dos equipos, formaciones y tácticas (compartidas con el laboratorio de jugadas).
- Escoge un intervalo de 1–45 minutos, equipo inicial y escenario. Simula todo, avanza una decisión o 30 segundos; puedes ampliar el intervalo finalizado cinco minutos sin reiniciar el reloj, hasta 45 min.
- Observa marcador, posesión por tiempo vivo, pérdidas, recuperaciones, transiciones, xG y registro. Exporta el registro JSON si quieres analizarlo. Los lotes de 1–1000 intervalos se ejecutan por bloques; cambiar ajustes cancela el resultado anterior.
- Energía fija; córneres y demás reanudaciones son aproximaciones. Las reglas y la fatiga se incorporarán después.

- Importa dos plantillas completas (mínimo 10 jugadores de campo y 1 portero cada una).
- En Laboratorio de jugadas elige los clubes y la formación. Despliega Once inicial para cambiar futbolistas; si eliges uno ya alineado, se intercambian los puestos. Los jugadores fuera de posición tienen penalización local, no se modifica su ficha.
- Despliega Tácticas de ambos equipos. Puedes elegir uno de nueve estilos y personalizar dieciséis instrucciones por equipo.
- Escoge uno de ocho escenarios, o configura una zona, organización defensiva y poseedor. La energía es fija durante cada experimento.
- Simular jugada ejecuta hasta el final; Paso a paso ejecuta una decisión (que puede contener varias acciones); Reiniciar vuelve al comienzo. Cambia la semilla para otro resultado; repetir la misma configuración y semilla reproduce el mismo experimento.
- Simular lote ejecuta de 1 a 10.000 posesiones independientes. Consulta métricas, finales, frecuencias de acción y xG del modelo. No equivale a una simulación de partido.

## Archivos

- `index.html`, `css/styles.css`: interfaz y estilo.
- `js/model.js`, `js/app.js`: editor, valoraciones, clubes e importación v1.
- `js/engine.js`, `js/lab.js`: motor individual e interfaz de acciones (v0.2).
- `js/formations.js`: seis formaciones, selección del once y compatibilidad posicional.
- `js/tactics.js`: dieciséis instrucciones, nueve presets.
- `js/possession.js`: máquina de estados de la posesión, independiente del DOM; prepara el contexto de continuidad.
- `js/possession-lab.js`: laboratorio colectivo.
- `js/sequence.js`, `js/sequence-lab.js`: núcleo de secuencias e interfaz.
- `SECUENCIAS.md`: continuidad, reloj, reanudaciones y puntos de integración de reglas/fatiga.
- `tests/sequence.test.js`: pruebas de secuencias. Ejecuta `node tests/sequence.test.js` o añade la ruta a tu JSON de LaLiga.
- `MOTOR.md`: fórmulas individuales. `POSESIONES.md`: hipótesis y reglas colectivas.
- `FootLab_formato.md`: especificación JSON v1.
- `tests/engine.test.js`, `tests/possession.test.js`: pruebas con Node.js, sin dependencias externas. Ejecuta `node tests/engine.test.js` y `node tests/possession.test.js`. Opcionalmente pasa la ruta a tu JSON de LaLiga a la segunda prueba.

El modelo aún no está calibrado con partidos reales. La navegación modular real debe comprobarse en GitHub Pages; las pruebas visuales de esta distribución cargaron los mismos scripts y CSS integrados en Chromium debido a restricciones de navegación del entorno de pruebas.
