# FootLab v0.3.2 · Motor de secuencias

## Objetivo
Encadenar posesiones en un intervalo de 1–45 minutos (UI), sin modelar aún las reglas completas ni el desgaste físico. La API acepta 1–2700 segundos. Las dos alineaciones y sus tácticas se mantienen, se invierte la perspectiva del campo al cambiar el poseedor. Las coordenadas siguen siendo 15 zonas, no trayectorias físicas. No hay localía, fatiga dinámica, lesiones, árbitro, sustituciones o instrucciones durante la secuencia.

## Estado y continuidad
`FLSequence.init(config, seed, durationSeconds)` crea un estado con equipos A/B, reloj, fase (`FLPossession`), lado en posesión, energía individual, marcador derivado de remates, estadísticas y registro cronológico. `tick(state, limit?)` avanza una decisión o una espera de reanudación, sin superar el límite (segundos absolutos). `run`, `extend` y `batch` reutilizan el mismo núcleo. La semilla se utiliza durante todo el intervalo, sin reiniciarse entre posesiones. En lote se usan semillas consecutivas, con desbordamiento uint32.

- Pérdida: cambia el lado, se invierten ambas coordenadas (x → 4−x, y → 2−y), el recuperador se convierte en poseedor inicial. La organización del equipo que acaba de perder el balón se calcula usando sus instrucciones y zona de pérdida.
- Gol: el equipo que recibe el gol reinicia en el centro tras una pausa de 28 s.
- Tiro fuera: saque de portería del rival tras 15 s.
- Parada con control: el portero tiene el balón, sin pausa obligatoria.
- Córner: el equipo atacante conserva el derecho a reanudar, se esperan 24 s y se inicia una fase normal en el carril exterior de la última franja. **No se ejecuta todavía un córner real:** no se elige lanzador, tipo de envío ni rematador específico.
- Límite de 40 acciones de la fase: frontera de cálculo, conserva balón, jugador, tiempo acumulado, RNG y organización; no cuenta como cambio de posesión ni genera una pausa.

Los tiempos de interrupción son constantes de diseño editables, no datos calibrados. El reloj separa segundos de balón vivo y parado. Si el límite temporal cae en mitad de una decisión compuesta, su resultado queda pendiente: se cuenta solo al completarse. Se conserva al ampliar el intervalo. Esto evita que haya goles posteriores al límite y permite reproducir el resultado con distintos tamaños de paso. El registro de una decisión compuesta se publica al terminar la decisión (con timestamps internos).

## Reorganización
Al perder el balón, la organización inicial es `clamp(.78 − .085*mental − .035*line − .023*width − .045*max(0, x−2) + ajuste, .18, .95)`; ajuste +.12 al replegarse, −.055 con contrapresión. En el código las instrucciones de cinco niveles usan índices 0–4. El equipo que defiende recupera organización por segundo de juego: `clamp(.026 + .0022*mediaTactica + .0013*mediaVelocidad + ajuste, .02, .08)`, ajuste +.013 para repliegue o −.008 para contrapresión. Los regates/pases que rompen líneas pueden volver a desorganizarlo. Los efectos de transición de la presión y la elección de acciones tienen ventanas temporales de 8–12 s. El modelo no conserva posiciones físicas individuales, solo el contexto agregado y las zonas derivadas del sistema anterior.

## Estadísticas
Posesión = tiempo vivo atribuido a cada lado, sin pausas. Un intervalo que empieza con un córner cuenta esa posesión inicial asignada aunque aún esté parado; después, se cuentan nuevos inicios al cambiar de lado y reanudarse. Una recuperación rival se atribuye al lado defensor; no se cuentan saques de portería como robos. Pérdida peligrosa = pérdida en las franjas 0–1 propias. Remates y xG de transición = remates completados dentro de los primeros 12 s desde el robo (también en escenarios iniciales de transición). Los pases completados conservan la definición del motor anterior: envío que supera su primera resolución; un duelo o control posterior aún puede fallar. xG es la suma de probabilidades de gol del modelo, no una métrica contrastada. Los datos de un intervalo no deben interpretarse como probabilidad de victoria en 90 minutos.

## Preparado para v0.3.3
- `state.energy` mantiene un valor 0–100 por ID de futbolista. `FLSequence.setEnergy(state,id,value)` lo actualiza en una frontera de decisión. `FLPossession.evaluate` consume la energía por ID cuando hay un proveedor; el laboratorio aislado conserva la energía fija por lado.
- `config.onDecision` es un callback opcional al completar una decisión, recibe `{clock, seconds, side, events, energy, setEnergy}`. Permite introducir el coste físico por acción y por tiempo sin modificar el importador ni las fichas base. Por defecto no se utiliza y no hay desgaste. Una futura recuperación durante pausas deberá añadirse al tramo de reloj detenido de `tick`.
- `FLPossession.end` produce una transición normalizada (`side, zone, holderId, restart, organization`). `FLSequence.complete` interpreta ese resultado y el mapa `restartDelay`; `tick` controla la pausa y `begin` la reanudación. Para introducir faltas, fueras de juego, saques de banda y penaltis habrá que añadir nuevos resultados, resolverlos en el punto causal de `FLPossession.step` y asociarlos a reanudaciones específicas. Todavía no hay un módulo de árbitro ni un motor de balón parado.
- El motor no depende del DOM. Las pruebas de Node validan la continuidad, atribución, límites temporales, extensión y determinismo.

## Calibración pendiente
La v0.3.2 puede generar demasiados remates y goles por minuto, demasiados cambios de posesión y ventajas excesivas de presión. No se han aplicado nerfeos ad hoc. Tras introducir reglas y fatiga habrá que contrastar tiempo efectivo, distribución de posesiones, remates, pases, xG y marcadores con fútbol real. Los coeficientes son hipótesis provisionales.
