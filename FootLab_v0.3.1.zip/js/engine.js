/* FootLab · motor de acciones v0.2. Sin DOM ni dependencias. */
(function(root){'use strict';
const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
const logit=p=>Math.log(p/(1-p));
const logistic=x=>1/(1+Math.exp(-x));
const F='campo',G='portero';
const w=(...pairs)=>Object.fromEntries(pairs);
const duel=(name,description,attack,defense,base,k=.55,extra={})=>({name,description,attack,defense,base,k,roles:[F,F],kind:'duel',...extra});
const shot=(name,description,attack,base,target,extra={})=>({name,description,attack,defense:w(['reflejos',.28],['estirada',.22],['colocacion',.22],['blocaje',.08],['concentracion',.10],['fortalezaMental',.10]),base,target,k:.38,roles:[F,G],kind:'shot',...extra});
const close=w(['definicion',.65],['compostura',.20],['potenciaTiro',.15]);
const long=w(['tiroLejano',.55],['potenciaTiro',.30],['compostura',.15]);
const actions={
 pase:duel('Pase','Completar un pase ante un rival que intenta cortar la línea.',w(['pase',.65],['vision',.25],['compostura',.10]),w(['intercepciones',.60],['tactica',.30],['aceleracion',.10]),.83,.45),
 control:duel('Control de balón','Recibir y conservar el balón bajo oposición.',w(['control',.65],['equilibrio',.20],['compostura',.15]),w(['entradas',.40],['marcaje',.35],['agilidad',.25]),.85,.45),
 regate:duel('Regate','Superar al defensor conservando la posesión.',w(['regate',.50],['control',.20],['agilidad',.20],['aceleracion',.10]),w(['entradas',.45],['marcaje',.25],['fuerza',.15],['agilidad',.15]),.50),
 entrada:duel('Entrada / robo','El defensor A recupera el balón limpiamente ante B.',w(['entradas',.60],['fuerza',.20],['marcaje',.20]),w(['regate',.45],['control',.35],['equilibrio',.20]),.50),
 intercepcion:duel('Intercepción','A corta el pase ejecutado por B.',w(['intercepciones',.60],['tactica',.30],['aceleracion',.10]),w(['pase',.65],['vision',.25],['compostura',.10]),.17,.45),
 desmarque:duel('Desmarque','A consigue separarse de su marcador B.',w(['tactica',.45],['aceleracion',.30],['velocidad',.25]),w(['marcaje',.50],['tactica',.30],['aceleracion',.20]),.55),
 velocidad:duel('Duelo de velocidad','A llega antes a un balón disputado, desde igualdad de partida.',w(['aceleracion',.50],['velocidad',.40],['agilidad',.10]),w(['aceleracion',.50],['velocidad',.40],['agilidad',.10]),.50,.65),
 fisico:duel('Duelo físico','A gana una disputa corporal contra B.',w(['fuerza',.55],['equilibrio',.35],['agilidad',.10]),w(['fuerza',.55],['equilibrio',.35],['agilidad',.10]),.50,.65),
 aereo:duel('Duelo aéreo','A gana el balón de cabeza ante B.',w(['salto',.40],['fuerza',.30],['cabezazo',.30]),w(['salto',.40],['fuerza',.30],['cabezazo',.30]),.50,.60),
 disparo:shot('Disparo dentro del área','Probabilidad de gol desde una ocasión interior ordinaria.',close,.15,.46),
 lejano:shot('Disparo lejano','Disparo desde fuera del área.',long,.06,.34),
 clara:shot('Ocasión clara','Remate con espacio y buena posición.',close,.35,.65),
 manoamano:shot('Mano a mano','Atacante frente al portero, con espacio para salir.',close,.45,.72,{defense:w(['salidas',.32],['reflejos',.25],['colocacion',.18],['estirada',.10],['fortalezaMental',.10],['concentracion',.05])}),
 cabezazo:shot('Remate de cabeza','Remate aéreo disputado dentro del área.',w(['cabezazo',.65],['salto',.20],['compostura',.15]),.10,.40),
 penalti:shot('Penalti','Lanzamiento desde los once metros.',w(['definicion',.50],['compostura',.40],['potenciaTiro',.10]),.76,.88,{defense:w(['reflejos',.32],['estirada',.25],['colocacion',.13],['fortalezaMental',.20],['concentracion',.10])}),
 parada:{name:'Parada (tiro a puerta)',description:'A es el portero; B es el rematador. Probabilidad condicionada a que el tiro vaya a puerta, desde dentro del área.',roles:[G,F],kind:'save',base:.15,target:.46,k:.38,attack:null,defense:null},
 salida:duel('Salida del portero','A intercepta un balón en profundidad antes de que B lo controle.',w(['salidas',.50],['colocacion',.25],['concentracion',.15],['fortalezaMental',.10]),w(['aceleracion',.40],['velocidad',.25],['control',.25],['tactica',.10]),.55,.55,{roles:[G,F]}),
 centro:duel('Centro aéreo / blocaje','El portero A domina un centro frente al rematador B.',w(['juegoAereo',.45],['salidas',.25],['blocaje',.20],['colocacion',.10]),w(['salto',.40],['fuerza',.25],['cabezazo',.35]),.65,.55,{roles:[G,F]}),
 saque:duel('Distribución del portero','A completa una distribución ante la presión de B.',w(['juegoBalon',.75],['concentracion',.15],['fortalezaMental',.10]),w(['intercepciones',.55],['tactica',.30],['aceleracion',.15]),.80,.45,{roles:[G,F]})
};
actions.parada.attack=actions.disparo.defense;actions.parada.defense=actions.disparo.attack;
const defaults={energyA:100,energyB:100,pressureA:0,pressureB:0,difficulty:0};
function context(c={}){const out={};for(const [k,v] of Object.entries(defaults)){const n=c[k]===undefined?v:Number(c[k]);if(!Number.isFinite(n))throw Error('Contexto inválido: '+k);out[k]=clamp(n,k==='difficulty'?-3:0,k.startsWith('energy')?100:k==='difficulty'?3:10)}out.traits=c.traits!==false;return out}
function type(p){return p?.posicion==='POR'?G:F}
function score(p,weights){let total=0;for(const [key,weight] of Object.entries(weights)){const value=p?.atributos?.[key];if(!Number.isInteger(value)||value<0||value>10)throw Error('Atributo inválido: '+key);total+=value*weight}return total}
function state(p,weights,energy,pressure){const raw=score(p,weights);const mental=p.posicion==='POR'?(.65*p.atributos.fortalezaMental+.35*p.atributos.concentracion):p.atributos.compostura;const resistance=p.posicion==='POR'?5:p.atributos.resistencia;const fatigue=(1-energy/100)*(2.5-.10*resistance);const stress=pressure/10*(1.5-.12*mental);return {raw,fatigue,stress,effective:clamp(raw-fatigue-stress,0,10)}}
function shotOdds(d,a,b,c){const diff=a.effective-b.effective;const target=logistic(logit(d.target)+.25*(a.effective-5)-.22*c.difficulty);const goal=target*logistic(logit(d.base/d.target)+d.k*diff-.30*c.difficulty);return {goal,save:target-goal,miss:1-target,target}}
function traitBonus(p,id,side){const traits=new Set((p.rasgos||[]).map(x=>x.toLowerCase().trim()));const rules={regate:[['filigranero',.35]],penalti:side==='A'?[['especialista en penaltis',.55]]:[['parapenaltis',.65]],manoamano:side==='B'?[['especialista en mano a mano',.5]]:[],salida:side==='A'?[['portero líbero',.4]]:[]};return (rules[id]||[]).filter(([t])=>traits.has(t)&&(id!=='regate'||side==='A')).reduce((s,[t,v])=>s+v,0)}
function addTraits(s,p,id,side,c){s.trait=c.traits?traitBonus(p,id,side):0;if(c.traits&&(p.rasgos||[]).some(t=>t.toLowerCase().trim()==='incansable')){s.fatigue*=.75} s.effective=clamp(s.raw-s.fatigue-s.stress+s.trait,0,10);return s}
function evaluate(id,pA,pB,opts={}){const d=actions[id];if(!d)throw Error('Acción desconocida');if(!pA||!pB||type(pA)!==d.roles[0]||type(pB)!==d.roles[1])throw Error('Selecciona los tipos de jugador requeridos.');const c=context(opts),a=addTraits(state(pA,d.attack,c.energyA,c.pressureA),pA,id,'A',c),b=addTraits(state(pB,d.defense,c.energyB,c.pressureB),pB,id,'B',c);let outcomes,probability,baseline;
 if(d.kind==='shot'){const s=shotOdds(d,a,b,c);outcomes=[{id:'gol',label:'Gol',p:s.goal},{id:'parada',label:'Parada',p:s.save},{id:'fuera',label:'Fuera / poste',p:s.miss}];probability=s.goal;baseline=d.base}
 else if(d.kind==='save'){const s=shotOdds(actions.disparo,b,a,{...c,difficulty:-c.difficulty});probability=s.target>0?s.save/s.target:0;outcomes=[{id:'parada',label:'Parada',p:probability},{id:'gol',label:'Gol',p:1-probability}];baseline=1-d.base/d.target}
 else{probability=logistic(logit(d.base)+d.k*(a.effective-b.effective)-.45*c.difficulty);outcomes=[{id:'exito',label:'Éxito de A',p:probability},{id:'fallo',label:'Éxito de B / fallo de A',p:1-probability}];baseline=d.base}
 return {id,a,b,c,probability,baseline,outcomes,kind:d.kind};}
function rng(seed){let a=seed>>>0;return ()=>{a=(a+0x6D2B79F5)|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return ((t^t>>>14)>>>0)/4294967296}}
function resolve(result,random=Math.random){let u=random();for(const o of result.outcomes){u-=o.p;if(u<0)return o.id}return result.outcomes.at(-1).id}
function batch(result,n,seed){if(!Number.isInteger(n)||n<1||n>100000)throw Error('Repeticiones: 1–100.000');if(!Number.isInteger(seed)||seed<0||seed>4294967295)throw Error('Semilla: entero 0–4294967295');const random=rng(seed),counts=Object.fromEntries(result.outcomes.map(o=>[o.id,0])),last=[];for(let i=0;i<n;i++){const id=resolve(result,random);counts[id]++;if(i>=n-15)last.push(id)}return {n,seed,counts,last}}
root.FLEngine=Object.freeze({version:'0.2',actions,defaults,evaluate,resolve,batch,rng});if(typeof module!=='undefined'&&module.exports)module.exports=root.FLEngine;
})(typeof globalThis!=='undefined'?globalThis:this);
