# Motor colectivo · v0.3.1

## Principios

La posesión se representa mediante un estado con poseedor, zona relativa al ataque, alineaciones, organización del rival, presión local, acciones, reloj, pases, remates y suma de probabilidades de gol. El campo consta de 5 franjas × 3 carriles. Los jugadores tienen anclajes nominales según su formación; su distribución aproximada se desplaza por fase, zona del balón, mentalidad, amplitud, línea y organización. No es física de 22 jugadores ni seguimiento de coordenadas reales.

Cada decisión enumera acciones legales, les asigna pesos positivos según contexto e instrucciones, y elige una mediante sorteo ponderado. La visión favorece acciones de progresión y la inteligencia táctica penaliza opciones con presión. Los pesos son parámetros experimentales, no frecuencias de fútbol observadas.

La presión combina la cercanía de defensores, intensidad, altura de inicio, orientación, organización y si se acaba de superar a un rival. Puede causar intentos de entrada además de modificar la dificultad contextual. Con intensidad cero no se intentan entradas activas de presión, pero aún existe oposición posicional. Los candidatos a receptor y defensor se seleccionan por distancia a la zona y, para el duelo aéreo, características relevantes. Son aproximaciones, no marcajes individuales persistentes.

## Resolución

- Pases atrás, laterales, verticales, cambios a banda y largos: `pase` o `saque`. Los balones elevados y largos generan disputa `aereo`; los pases progresivos rasos pueden requerir `control`. Un pase completado significa entrega exitosa antes de la disputa o control posterior.
- Regates: `regate`; la presión activa se resuelve con `entrada`.
- Centros: envío, posible salida `centro` del portero y disputa aérea o control; si se supera, se remata.
- Tiros: `lejano`, `disparo`, `clara`, `manoamano`, `cabezazo` según zona y organización. Se resuelven con el motor v0.2. Una parada puede ser blocada, generar córner o un rebote ofensivo; el blocaje del portero influye.
- Los modificadores de dificultad dependen de presión, tipo de envío, ritmo y adaptación posicional. No alteran los atributos persistentes ni la media. La energía inicial alimenta el motor individual; aún no disminuye durante las acciones.
- La duración se deriva del tipo de acción y ritmo, con variación aleatoria reproducible. El paso lógico puede incluir varias acciones. El límite de seguridad se aplica tras la decisión al llegar a 40 acciones (puede sobrepasarlo ligeramente una secuencia); se marca como continuación, nunca como pérdida artificial.

## Final y continuidad

`gol`, `perdida`, `parada`, `fuera`, `corner`, `limite`. `next` registra equipo que tendrá la posesión (A/B), zona relativa a ese equipo (se invierten ambos ejes al cambiar posesión), posible poseedor, clase de reinicio y organización inicial aproximada. El motor no ejecuta ese reinicio todavía. Los córneres se detectan como final de fase, no se simulan. Los postes sin rebote se agrupan con tiros fuera como simplificación. No se simulan faltas, fuera de juego, saques de banda, bloqueos de disparos detallados ni despejes con rebote a un tercero aún.

## Tácticas

16 parámetros independientes. Mentalidad y verticalidad cambian el peso de acciones y la mentalidad también mueve anclajes. Ritmo cambia duración y dificultad de ejecución. Amplitud cambia distribución y juego exterior. Libertad modifica tendencia de regate. Canal, salida, creación y tipo de centro sesgan los envíos. Recuperar y perder modifican las primeras decisiones en situaciones de transición y la recuperación defensiva. Presión, línea, altura de inicio, anchura defensiva y orientación modifican la forma y oposición. Las instrucciones no son garantías: puede haber excepciones por la situación y aleatoriedad. La salida se prioriza en las primeras acciones en campo propio.

## Contrato de código

`FLFormations.auto(players, formation, rating)` → IDs del once. `FLFormations.lineup(players, formation, ids)` → slots con `p`, `pos`, `x`, `y`, `fit`. `FLTactics.normalize` valida una táctica. `FLPossession.init(config, FLEngine.rng(seed))` crea estado, `step(s)` ejecuta una decisión, `run(config, rng)` completa posesión, `batch(config, n, seed)` devuelve estadísticas. El estado es mutable para el avance y no escribe en la BD. Los lotes no almacenan los relatos de todas las jugadas. Cada experimento comienza con estado independiente; no hay fatiga acumulada ni marcador persistente.

El xG es la suma de probabilidades de gol evaluadas por el modelo individual, **no una estimación calibrada con fútbol real**. Las frecuencias y pesos deberán ajustarse con los futuros partidos y datos de referencia. Las pruebas comprueban invariantes, reproducibilidad y efectos direccionales de varias tácticas, no la validez empírica de todos los coeficientes.
