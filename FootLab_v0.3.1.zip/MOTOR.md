# Motor de acciones v0.2

El motor no emplea la media global o posicional de los jugadores. Cada acción define atributos, pesos, tipos de participantes y probabilidad base de referencia. Todos los pesos, pendientes y probabilidades se pueden editar en `js/engine.js`.

## Duelos

Capacidad base = suma de los atributos multiplicados por sus pesos (0–10). Capacidad efectiva = base − fatiga − presión + rasgo, limitada entre 0 y 10.

P(éxito A) = logística(logit(pBase) + k × (capacidadA − capacidadB) − 0,45 × dificultad).

La fatiga es (1 − energía/100) × (2,5 − 0,10 × resistencia). Para porteros se usa resistencia neutral 5. La presión es presión/10 × (1,5 − 0,12 × mental); en jugadores de campo mental = compostura, en porteros = 65% fortaleza mental + 35% concentración.

## Remates

Se estima la probabilidad de tiro a puerta y después la probabilidad de gol condicionada a que vaya a puerta, mediante dos curvas logísticas. Gol = producto de ambas. Parada = probabilidad de tiro a puerta menos gol; fuera/poste = complemento de tiro a puerta. El portero afecta la conversión, no la puntería del atacante. En la acción «Parada» se usa solo la probabilidad condicionada a un tiro a puerta. No existen todavía bloqueos, rebotes o goles en propia puerta.

## Rasgos activos

- Filigranero: +0,35 capacidad en regate.
- Especialista en penaltis: +0,55 capacidad al lanzar.
- Parapenaltis: +0,65 capacidad al defender penaltis.
- Especialista en mano a mano: +0,50 capacidad del portero en mano a mano.
- Portero líbero: +0,40 capacidad en salida.
- Incansable: reduce la penalización por fatiga un 25%.

Otros rasgos siguen almacenados pero todavía no tienen efecto. Los bonos y penalizaciones son experimentales. Los valores efectivos se limitan a 0–10, de modo que un bono puede saturar al llegar al máximo.

## API del motor

`FLEngine.evaluate(id, jugadorA, jugadorB, contexto)` calcula probabilidades y desglose. `FLEngine.resolve(resultado, random)` elige un resultado. `FLEngine.batch(resultado, n, seed)` realiza experimentos reproducibles. `FLEngine.rng(seed)` genera números pseudoaleatorios. `FLEngine.actions` contiene las definiciones.

Los parámetros del contexto son `energyA/B` (0–100), `pressureA/B` (0–10), `difficulty` (−3 a 3), `traits` (booleano). La dificultad siempre se interpreta desde A. La simulación no cambia los atributos ni consume energía automáticamente; esto se implementará en el motor de posesiones.
